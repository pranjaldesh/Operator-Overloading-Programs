//Binary Arithmatic Minus operator overloading
#include<iostream>
#include<stdlib.h>
class demo
{
    public:
    int a,b,c;
    demo(int a,int b,int c)
    {
        this->a=a;
        this->b=b;
        this->c=c;
    }
    demo(const demo& other)/*In this program no need of copy constuctor but
                              it is always better to write*/
    {
        this->a=other.a;
        this->b=other.b;
        this->c=other.c;
    }
    demo& operator-(const demo& other)
    {
    demo* objptr=(demo*)malloc(sizeof(demo));
    objptr->a=this->a-other.a;
    objptr->b=this->b-other.b;
    objptr->c=this->c-other.c;
    return *objptr;
    }
};
int main()
{
    demo d1(50,70,90);
    demo d2(40,50,60);
    demo d3=d1-d2;
    std::cout<<d3.a<<std::endl<<d3.b<<std::endl<<d3.c<<std::endl;
    return 0;
}