#include<iostream>
#include<stdio.h>
class demo
{
    public:
    int a;
    int b;
    int* p;
    demo()
    {

    }
    demo(int a,int b,int p)
    {
        this->a=a;
        this->b=b;
        this->p=(int*)malloc(sizeof(int));
        *(this->p)=p;
    }
    demo(const demo& other)
    {
        this->a=other.a;
        this->b=other.b;
        this->p=(int*)malloc(sizeof(int));
        *(this->p)=*(other.p);
    }
    
};
int main()
{
    
    demo d(10,20,30);
    demo d4;
    std::cout<<"Data Members of Object d=>"<<std::endl;
    std::cout<<d.a<<std::endl<<d.b<<std::endl<<*(d.p)<<std::endl;
    std::cout<<"Data Members of Object d4=>"<<std::endl;
    std::cout<<d4.a<<std::endl<<d4.b<<std::endl<<*(d4.p)<<std::endl;
    d4=d;
    std::cout<<"Data Members of Object d4=>"<<std::endl;
    (*(d4.p))++;
    std::cout<<d4.a<<std::endl<<d4.b<<std::endl<<*(d4.p)<<std::endl;
    std::cout<<"Data Members of Object d=>"<<std::endl;
    std::cout<<d.a<<std::endl<<d.b<<std::endl<<*(d.p)<<std::endl;
    return 0;
}