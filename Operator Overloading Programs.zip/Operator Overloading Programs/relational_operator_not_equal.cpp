//Relational Operator(!=)
#include<iostream>
class demo
{
    private:
    int a,b,c;
    public:
    demo(int a,int b,int c)
    {
        this->a=a;
        this->b=b;
        this->c=c;
    }
    int operator!=(demo& other)
    {
        return((this->a!=other.a)||
                (this->b!=other.b)||
                (this->c!=other.c));
    }
};
int main()
{
    demo d1(10,20,30);
    demo d2(40,50,60);
    demo d3(10,20,39);

    if(d1!=d3)
    {
        std::cout<<"true";
    }
    else
    {
        std::cout<<"false";
    }
    return 0;
}