//Increment Operator Overloading
#include<iostream>
class demo
{
    private:
    int a,b,c;
    public:
demo(int a,int b,int c)
{
    this->a=a;
    this->b=b;
    this->c=c;
}
friend std::ostream& operator<<(std::ostream& out,demo& other);

demo& operator++()//preincrement
{
    (this->a)++;
    ++(this->b);
    ++(this->c);
    return (*this);
}
demo operator++(int x)//postincrement
{
    demo y=*this;
    (this->a)++;
    (this->b)++;
    (this->c)++;
    return y;
}
};
 std::ostream& operator<<(std::ostream& out,demo& other)
{
    out<<other.a<<"\t";
    out<<other.b<<"\t";
    out<<other.c<<"\t";
    return out;
}
int main()
{
    demo d1(10,20,30);
    demo d2=d1++;
    demo d3=++d1;
    std::cout<<d1<<std::endl<<d2<<std::endl<<d3<<std::endl;
    return 0;
}