#include<iostream>
#include<stdio.h>
class demo
{
    public:
    int a,b,c;
    demo(int a,int b,int c)
    {
        this->a=a;
        this->b=b;
        this->c=c;
    }
demo& operator+(const demo& other)
{
    demo* objptr=(demo*)malloc(sizeof(demo));
    d3.a=this->a+other.a;
    d3.a=this->a+other.a;
    d3.a=this->a+other.a;
    return *objptr;
}
};
int main()
{
    demo d1(10,20,30);
    demo d2(40,50,60);
    demo d3=d1+d2;
    std::cout<<d3;
    return 0;
}